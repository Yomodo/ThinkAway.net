﻿using System;
using System.Net.Sockets;

namespace ThinkAway.Net.Sockets
{
    public class  AppClient<TProtocol> where TProtocol : Protocol, new()
    {
        private readonly AppSocket _appSocket;

        private readonly TProtocol _protocol;

        public AppClient()
        {
            _protocol = new TProtocol();
            _protocol.HandleMessage += _protocol_HandleMessage;

            Socket socket = new Socket(AddressFamily.InterNetwork,SocketType.Stream, ProtocolType.Tcp);
            _appSocket = new AppSocket(ref  socket);
            _appSocket.Received += appSocket_Received;
            _appSocket.Disconnected += appSocket_Disconnected;
        }

        void _protocol_HandleMessage(Protocol protocol)
        {
            throw new System.NotImplementedException();
        }

        void appSocket_Received(object sender, ReceivedEventArgs e)
        {
            _protocol.Post(e.Data);
        }
        public void Connect(string host,int port)
        {
            Socket clientSocket = _appSocket.ClientSocket;
            clientSocket.BeginConnect(host, port, ConnectCallback, clientSocket);
            _appSocket.ReceiveData();
        }

        private void ConnectCallback(IAsyncResult ar)
        {
            Socket socket = (Socket) ar.AsyncState;
            socket.EndConnect(ar);
        }

        void appSocket_Disconnected(object sender, DisconnectedEventArgs e)
        {
            throw new System.NotImplementedException();
        }


        public void Send(TProtocol data)
        {
            _appSocket.SendData(data.GetBytes());
        }
    }
}