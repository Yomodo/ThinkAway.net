﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using ThinkAway.IO.Log;

/*
 * Lsong
 * i@lsong.org
 * http://lsong.org
 */
namespace ThinkAway.Net.Sockets
{
    public class AppServer
    {
        private readonly ILog log;

        private Socket _listener;

        private bool _listenerRun;

        public const int MAX_SESSION_COUNT = 100;

        private readonly SessionManager _sessionsManager;

        public  SessionManager Sessions
        {
            get { return _sessionsManager; }
        }

        private readonly Dictionary<string, Protocol> _dictionary;

        public event EventHandler<ReceivedEventArgs> Received;

        public void OnReceived(ReceivedEventArgs e)
        {
            EventHandler<ReceivedEventArgs> handler = Received;
            if (handler != null) handler(this, e);
        }

        public event EventHandler<ConnectedEventArgs> Connected;

        public void OnConnected(ConnectedEventArgs e)
        {
            EventHandler<ConnectedEventArgs> handler = Connected;
            if (handler != null) handler(this, e);
        }

        public event EventHandler<DisconnectedEventArgs> Disconnected;

        public void OnDisconnected(DisconnectedEventArgs e)
        {
            EventHandler<DisconnectedEventArgs> handler = Disconnected;
            if (handler != null) handler(this, e);
        }
        /// <summary>
        /// AppServer
        /// </summary>
        /// <param name="port"></param>
        public AppServer(int port)
        {
            log = new Logger();

            log.Config.Mode = LogMode.Console;

            _dictionary = new Dictionary<string, Protocol>();

            _sessionsManager = new SessionManager();
            _sessionsManager.SessionStarted += SessionStarted;
            _sessionsManager.SessionStoped += SessionStoped;
            
            IPEndPoint ipEndPoint = new IPEndPoint(IPAddress.Any, port);
            _listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            _listener.Bind(ipEndPoint);

            log.Debug("log", "AppServer Started.");
        }

        public void StartListener()
        {
            _listenerRun = true;
            _listener.Listen(50);

            log.Debug("log", "AppServer Listening .");

            _listener.BeginAccept(AcceptCallBack, _listener);

            log.Debug("log", "AppServer BeginAccept .");
        }

        public void StopListener()
        {
            _listenerRun = false;
            //_listener.Shutdown(SocketShutdown.Both);
            //_listener.Disconnect(false);
            _listener.Close();
            _listener = null;
        }

        protected virtual void SessionStarted(object sender, SessionEventArgs e)
        {
            _dictionary.Add(e.SessionKey, new Protocol());

            AppSession appSession = _sessionsManager[e.SessionKey];
            AppSocket appSocket = appSession.AppSocket;
            appSocket.ReceiveData();

            log.Debug("log", "_sessionsManager_SessionStarted:{0}", e.SessionKey);
        }

        protected virtual void SessionStoped(object sender, SessionEventArgs e)
        {
            _dictionary[e.SessionKey].Over += AppServer_Over;

            log.Debug("log", "_sessionsManager_SessionStoped:{0}",e.SessionKey);
        }

        void AppServer_Over(object obj)
        {
            Protocol protocol = (Protocol) obj;
            protocol.Dispose();
            string[] keys = new string[_dictionary.Count];
            _dictionary.Keys.CopyTo(keys,0);
            foreach (var key in keys)
            {
                if(_dictionary[key] == protocol)
                {
                    _dictionary.Remove(key);
                }
            }
        }

        private void AcceptCallBack(IAsyncResult asyncResult)
        {
            if(_listenerRun)
            {
                Socket socket = (Socket)asyncResult.AsyncState;
                Socket client = socket.EndAccept(asyncResult);
                //
                SocketAcceptCallBack(client);
                //
                if (_listenerRun && _sessionsManager.SessionCount < MAX_SESSION_COUNT)
                {
                    _listener.BeginAccept(AcceptCallBack, _listener);
                }
            }
        }

        protected void SocketAcceptCallBack(Socket client)
        {
            AppSocket appSocket = new AppSocket(ref client);
            appSocket.Disconnected += OnDisconnected;
            appSocket.Received += OnReceived;
            _sessionsManager.Add(appSocket);
        }

        protected virtual void OnDisconnected(object sender, DisconnectedEventArgs e)
        {
            SessionEventArgs sessionEventArgs = new SessionEventArgs();
            int hashCode = sender.GetHashCode();
            string key = hashCode.ToString(CultureInfo.InvariantCulture);
            sessionEventArgs.SessionKey = key;
            _sessionsManager.OnSessionStoped(sessionEventArgs);
        }

        protected virtual void OnReceived(object sender, ReceivedEventArgs e)
        {
            int hashCode = sender.GetHashCode();
            string key = hashCode.ToString(CultureInfo.InvariantCulture);
            if (_dictionary.ContainsKey(key))
            {
                Protocol protocol = _dictionary[key];
                protocol.Post(e.Data);
            }
        }
    }
}