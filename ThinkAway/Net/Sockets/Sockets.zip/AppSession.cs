﻿using System;
using System.Globalization;

namespace ThinkAway.Net.Sockets
{
	/// <summary>
	/// 客户端管理器
	/// </summary>
    public class AppSession
	{
	    /// <summary>
        /// SessionKey
        /// </summary>
        public string SessionKey
        {
            get
            {
                int hashCode = _appSocket.GetHashCode();
                return hashCode.ToString(CultureInfo.InvariantCulture);
            }
        }
        private AppSocket _appSocket;

	    /// <summary>
		/// 获取或设置服务器通与客户端通信时使用的套接字
		/// </summary>
		public AppSocket AppSocket
	    {
	        get { return _appSocket; }
	        private set { _appSocket = value; }
	    }
        /// <summary>
        /// 最后一次活跃时间
        /// </summary>
	    public DateTime LastTime { get; private set; }

	    public AppSession(AppSocket appSocket)
	    {
            LastTime = System.DateTime.Now;

	        AppSocket = appSocket;
            AppSocket.Received += AppSocket_Received;
	    }

        void AppSocket_Received(object sender, ReceivedEventArgs e)
        {
            LastTime = System.DateTime.Now;
        }
		/// <summary>
		/// 让管理器停止工作，并回收资源
		/// </summary>
		public void Stop()
		{
			Dispose();
		}
	    /// <summary>
		/// 执行与释放或重置非托管资源相关的应用程序定义的任务。
		/// </summary>
		public void Dispose()
		{
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// 析构函数
		/// </summary>
		~AppSession()
		{
			Dispose();
		}
    }
}