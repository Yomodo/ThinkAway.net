using System;

namespace ThinkAway.Net.Sockets
{
    /// <summary>
    /// 
    /// </summary>
    public class ConnectedEventArgs : EventArgs
    {
    }
}