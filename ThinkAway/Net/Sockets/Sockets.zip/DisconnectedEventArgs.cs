using System;

namespace ThinkAway.Net.Sockets
{
    public class DisconnectedEventArgs : EventArgs
    {
    }
}