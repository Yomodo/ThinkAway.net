﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace ThinkAway.Net.Sockets
{
    public class Protocol : IDisposable
    {
        private bool running;

        private readonly List<byte[]> _list;

        private readonly Thread _thread;

        public event Action<object> Over;

        public void OnOver()
        {
            Action<object> handler = Over;
            if (handler != null) handler(this);
        }

        public event Action<Protocol> HandleMessage;

        public void OnHandleMessage(Protocol e)
        {
            Action<Protocol> handler = HandleMessage;
            if (handler != null) handler(e);
        }

        //private readonly AutoResetEvent _autoResetEvent;

        public Protocol()
        {
            //_autoResetEvent = new AutoResetEvent(false);
            _list = new List<byte[]>();

            running = true;

            _thread = new Thread(ParseMessage);
            _thread.Name = "ProtocolThread";
            
            _thread.Start();
        }

        protected internal byte[] GetBytes()
        {
            return System.Text.Encoding.UTF8.GetBytes("Hello !");
        }

        internal void Post(byte[] data)
        {
            //_list.Add(data);
            //_autoResetEvent.Set();
            System.Console.WriteLine(System.Text.Encoding.UTF8.GetString(data));
        }

        void ParseMessage()
        {
            while (running)
            {
                if (_list.Count == 0)
                    break;
                Thread.Sleep(3000);
                //_autoResetEvent.WaitOne();
                System.Console.WriteLine("寄存器剩余信息数:{0}", _list.Count);
                byte[] bytes = _list[0];
                System.Console.WriteLine(System.Text.Encoding.UTF8.GetString(bytes));
                _list.RemoveAt(0);
                if (_list.Count == 0)
                {
                    OnOver();
                    //_autoResetEvent.Reset();
                }
            }
        }

        #region Implementation of IDisposable

        public void Dispose()
        {
            running = false;
        }

        #endregion
    }
}
