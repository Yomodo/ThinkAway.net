﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Timers;

namespace ThinkAway.Net.Sockets
{
    public class SessionManager
    {
        private const int Interval = 5000;

        private const int SessionTime = 5;

        private readonly Timer _timer;
        
        private readonly IDictionary _dictionary;

        /// <summary>
        /// 当用户成功登录时发生。
        /// </summary>
        public event EventHandler<SessionEventArgs> SessionStarted;

        public void OnSessionStarted(SessionEventArgs e)
        {
            EventHandler<SessionEventArgs> handler = SessionStarted;
            if (handler != null) handler(this, e);
        }
        /// <summary>
        /// 当用户成功注销时发生。
        /// </summary>
        public event EventHandler<SessionEventArgs> SessionStoped;

        public void OnSessionStoped(SessionEventArgs e)
        {
            EventHandler<SessionEventArgs> handler = SessionStoped;
            if (handler != null) handler(this, e);
        }

        public SessionManager()
        {
            _dictionary = new Dictionary<string, AppSession>();

            _timer = new Timer(Interval);
            _timer.Elapsed += TimerElapsed;
            _timer.Start();
        }

        void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            ArrayList arrayList = new ArrayList(_dictionary.Keys);
            foreach (string key in arrayList)
            {
                AppSession appSession = (AppSession)_dictionary[key];
                TimeSpan timeSpan = DateTime.Now - appSession.LastTime;

                if (timeSpan.Seconds > SessionTime)
                {
                    _dictionary.Remove(key);

                    SessionEventArgs sessionEventArgs = new SessionEventArgs();
                    sessionEventArgs.SessionKey = appSession.SessionKey;
                    OnSessionStoped(sessionEventArgs);
                }
            }
        }

        public int SessionCount
        {
            get { return _dictionary.Count; }
        }

        internal void Add(AppSocket appSocket)
        {
            AppSession appSession = new AppSession(appSocket);
            _dictionary.Add(appSession.SessionKey,appSession);
            //
            SessionEventArgs sessionEventArgs = new SessionEventArgs();
            sessionEventArgs.SessionKey = appSession.SessionKey;
            OnSessionStarted(sessionEventArgs);
        }

        public AppSession this[string sessionKey]
        {
            get { return (AppSession) _dictionary[sessionKey]; }
        }
    }
}
